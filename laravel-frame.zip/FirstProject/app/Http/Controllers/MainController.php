<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
//use Validator;
use Auth;
use DB;
use App\User;

class MainController extends Controller
{
  public function register(Request $request)
  {
    $users=new User();
    $users->name=$request->input("name");
    $users->email=$request->input("email");
    $users->mobile_no=$request->input("mobile_no");
    $users->password=$request->input("password");
    $users->save();
    return response()->json(["user"=>$users],201); 
  }
  public function login(Request $request)
  {
    $user_data = array();
      if(is_numeric($request->get('email')))
      {
         $user_data['mobile_no']=$request->get('email');
         $user_data['password']=$request->get('password');
      }
      else
      {
         $user_data['email']=$request->get('email');
         $user_data['password']=$request->get('password');
      }
     if(Auth::attempt($user_data))
     {
      return response()->json(compact('token'));
     }
     else
     {
      return response()->json(["error"=>'Invalid Creditions'],400);
     }

  }
  public function task()
  {
    $users = DB::table('users')->select('id','name','email','mobile_no')->get();
    $response=[
      "user_data"=>$users
    ];
    return response()->json(["user"=>$response],201);
      //$response,200);
  }
}
?>