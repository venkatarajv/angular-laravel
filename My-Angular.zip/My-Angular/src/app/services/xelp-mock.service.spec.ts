import { TestBed } from '@angular/core/testing';

import { XelpMockService } from './xelp-mock.service';

describe('XelpMockService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: XelpMockService = TestBed.get(XelpMockService);
    expect(service).toBeTruthy();
  });
});
